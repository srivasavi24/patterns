package jcfdemo;
import java.util.*;

public class JavaCollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> list = new LinkedList<>();
		list.add("C");list.add("python");list.add("java");
		list.add(1, "csharp");
		//print list
		System.out.println("Elements in list :"+ list);
		//list update 
		list.set(2, "dotnet");
		System.out.println("Elements in list after updating :"+ list);
		
		//remove an element
		list.remove(3);
		System.out.println("Elements in list after removing:"+ list);
		
		//addfirst
		list.addFirst("c++");
		list.addLast("snake");
		System.out.println("Elements in list after adding:"+ list);
		
		//clear
//		list.clear();
//		System.out.println("After clear operation :" + list);
		
		ListIterator<String> itr = list.listIterator();
//		System.out.println(itr.hasNext());
//		System.out.println(itr.next());
//		System.out.println(itr.next());
//		System.out.println(itr.next());
//		System.out.println(itr.next());
//		System.out.println(itr.next());
		
	
		while(itr.hasNext()) {
			System.out.println(itr.next());
		
		}
		
		
		
		
		
		
		
		
		
	}

}
