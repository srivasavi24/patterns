package doublyLinkiedList;

public class Driver {
	
	public static void print(Node head) {
		Node current = head;
		while(current!=null) {
			System.out.print(current.name+"->");
			current = current.next;
		}
	}
	
	public static Node printBackward(Node head) {
		Node current = head;
		System.out.println("\nPrinting Forward");
		while(current.next !=null) {
			System.out.print(current.name+"->");
			current = current.next;
		}
		
		System.out.println("Last Node: "+current.name);
		// Printing backwards
		
		System.out.println("Printing Backwards");
		while(current !=null) {
			System.out.print(current.name+"->");
			current = current.prev;		
		}
		return head;
		
		
	}
	
//	public static Node swap(Node fNode, Node lNode) {
//
//	}
	public static void main(String[] args) {
		Node fNode = new Node("Sushma");
		Node sNode = new Node("Priya");
		Node tNode = new Node("Rachana");
		Node fourthNode = new Node("Mahitha");
		Node fifthNode = new Node("Sree Lakshmi");
		Node sixNode = new Node("Pramila");
		Node sevenNode = new Node("Akhila");
		Node eightNode = new Node("Shabna");
		Node nineNode = new Node("Abhishek");
		
		// Forward Linking
		fNode.next = sNode;
		sNode.next = tNode;
		tNode.next = fourthNode;
		fourthNode.next = fifthNode;
		fifthNode.next = sixNode;
		sixNode.next = sevenNode;
		sevenNode.next = eightNode;
		eightNode.next = nineNode;
		
		// Linking Backward
		nineNode.prev = eightNode;
		eightNode.prev = sevenNode;
		sevenNode.prev = sixNode;
		sixNode.prev = fifthNode;
		fifthNode.prev = fourthNode;
		fourthNode.prev = tNode;
		tNode.prev = sNode;
		sNode.prev = fNode;
		
		//Printing the Linked List
		print(fNode);
		
		printBackward(fNode);
	}
}
