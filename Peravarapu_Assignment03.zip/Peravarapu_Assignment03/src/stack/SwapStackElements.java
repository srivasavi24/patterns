package stack;
import java.util.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class SwapStackElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);
		
		Stack<Integer> integerStack = new Stack<>();
		
		System.out.print("Enter the capacity: ");
		int size= in.nextInt();
		System.out.println("Enter "+size+" numbers:");
		for(int i=0;i<size;i++) {
			//Reading input elements
			int elements= in.nextInt();
			//pushing the elements to the stack
			integerStack.push(elements);
		}
		System.out.println("Stack Elements: "+integerStack);
		System.out.print("Enter the first index to swap: ");
		int firstValue=in.nextInt();
		
		System.out.print("Enter the second index to swap: ");
		int secondValue=in.nextInt();
		int t1=firstValue,t2=secondValue;
		int temp1,temp2;
		if(firstValue<=size && firstValue>=0&& secondValue<=size && secondValue>=0) {
			temp1=integerStack.elementAt(firstValue);
			temp2=integerStack.elementAt(secondValue);
			
			integerStack.add(t1,temp2);
			integerStack.remove((firstValue+1));
			
			integerStack.add(t2,temp1);
			integerStack.remove((secondValue+1));
			
			System.out.println("After swapping the stack: "+integerStack);
		}
		else {
			System.out.println("Invalid indices.");
		}
	}

}
