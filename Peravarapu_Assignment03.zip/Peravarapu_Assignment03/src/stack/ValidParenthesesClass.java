/**
 * 
 */
package stack;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */
import java.util.*;

public class ValidParenthesesClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner class to read input from the user
		Scanner in = new Scanner(System.in);
		System.out.print("Enter any String: ");
		String userInput = in.next();
		
		//stack objects to push the character of the string to respective stacks
		Stack<String> operands = new Stack<>();
		Stack<String> operators = new Stack<>();
		Stack<String> braces = new Stack<>();
		
		
		Stack<String> balance = new Stack<>();

		String s;
		int c = 0;
		char character;
		for (int i = 0; i < userInput.length(); i++) {

			character = userInput.charAt(i);
			boolean ch = Character.isAlphabetic(character);
			boolean nu = Character.isDigit(character);
			if (character == '@' || character == '#' || character == '$' || character == '^' || character == '&'
					|| character == '!' || character == '~' || character == '<' || character == '>' || character == '.'
					|| character == ',' || character == '|' || character == '"' || character == ';' || character == ':'
					|| character == ' ' || character == '?' || character == '_') {
				c = c + 1;
				break;
			} 
			else {
				if (ch) {
					s = String.valueOf(character);
					operands.push(s);
				} 
				else if (nu) {
					s = String.valueOf(character);
					operands.push(s);
				} 
				else if (character == '+' || character == '-' || character == '*' || character == '/' || character == '%') {
					s = String.valueOf(character);
					operators.push(s);
				}

				else if (character == '(' || character == ')' || character == '{' || character == '}'
						|| character == '[' || character == ']') {
					s = String.valueOf(character);
					braces.push(s);

				}
			}

		}
		if (c != 0) {
			System.out.println("Input String must contain numbers, alphabets, and mathematical operators.");
		} else {
			System.out.println("Operands stack: " + operands);
			System.out.println("Operators stack: " + operators);
			System.out.println("braces stack: " + braces);

			for (String p : braces) {
				if (p.equals("{") || p.equals("(") || p.equals("[")) {
					balance.push(p);
				} else {
					if (balance.size() == 0) {
						balance.push(p);
					} else {
						balance.pop();
					}
				}
			}
			if (balance.isEmpty() == false) {
				System.out.println("The braces aren't closed correctly");
			} else {
				System.out.println("The braces are closed correclty");
			}

		}

		in.close();
	}

}
