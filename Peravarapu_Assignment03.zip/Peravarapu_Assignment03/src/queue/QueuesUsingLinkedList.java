package queue;
import java.util.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class QueuesUsingLinkedList {
	Queue<Integer> queue = new LinkedList<>();
	Node head;
	/*
	 * enqueue method to insert element at end
	 */
	public void enqueue(int x) {
		Node node= new Node(x);
		if(head==null) {
			head=node;
		}
		else {
			Node rand=head;
			while(rand.next!=null) {
				rand=rand.next;
			}
			rand.next=node;
		}
		
	}
	/*
	 * dequeue method to remove element at front
	 */
	public int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue is empty");
			return -1;
		}
		else {
			int rand=head.data;
			head = head.next;
			return rand;
		
		}
	}
	/*
	 * method to check whether to check queue is empty or not
	 */
	public boolean isEmpty() {
		if(head==null) {
			return true;
		}
		else
			return false;
	}
	/*
	 * method size() to know the size of the queue
	 */
	public int size() {
		int x = 0;
	 Node rand = head;
	 while(rand!=null) {
		 rand = rand.next;
		 x++;
	 }
	 return x;
	}
	/*
	 * method to print the elements in the queue
	 */
	public void print() {
		Node rand = head;
		 System.out.print("Elements in queue: [");
		 while(rand.next!=null) {
			 System.out.print(rand.data+",");
			 rand = rand.next;
		 }
		 System.out.print(rand.data+"]\n");
	}
	
}
