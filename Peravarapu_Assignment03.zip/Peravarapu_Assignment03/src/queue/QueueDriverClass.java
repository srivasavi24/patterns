package queue;

import java.util.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class QueueDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Node queueObject = new Node();

		QueuesUsingLinkedList queueObject = new QueuesUsingLinkedList();
		
		Scanner scanner = new Scanner(System.in);
		char choice;
		do {

			System.out.println("Queue using Linked List Operations ");
			System.out.println("1.Enqueue\n2.Dequeue\n3.Print\n4.Size\n5.Check Empty or not\n6.Exit");
			System.out.print("Enter your choice: ");
			int ch = scanner.nextInt();
			switch(ch) {
			case 1:
				System.out.print("Enter an element to insert: ");
				int num=scanner.nextInt();
				queueObject.enqueue(num);
				System.out.println(num +" is inserted into the queue");
				break;
			case 2:
				int rem=queueObject.dequeue();
				if(rem==-1) {
					continue;
				}
				else
					System.out.println(rem+" is removed from queue");
				
				break;
			case 3:
				queueObject.print();
				break;
			case 4:
				System.out.println("Size of the queue = "+queueObject.size());
				break;
			case 5:
				if(queueObject.isEmpty()) {
					System.out.println("Queue is empty");
				}
				else
					System.out.println("Queue is not empty");
				break;
			case 6:
				System.out.print("Do you want to exit(y/n): ");
				choice = scanner.next().charAt(0);
				if(choice == 'y' || choice == 'Y') {
					System.out.println("Operations on queue are done.");
					System.exit(0);
					break;
				}
				break;
			default:
				System.out.println("The choice is not present in the list");
			}
			
		} while (true);

	}

}
