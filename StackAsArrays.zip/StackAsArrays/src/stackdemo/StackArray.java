package stackdemo;

import java.util.*;

public class StackArray {
	int[] stackArr;
	int top;
	int maxSize;

	// constructor
	public StackArray(int size) {
		top = -1;
		maxSize = size;
		stackArr = new int[size];
	}

	public void myPush(int num) {
		// update the top to move the index
		if (isFull() == false) {
			top = top + 1;
			stackArr[top] = num;
		} else {
			System.out.println("Stack is full cannot insert elements");
		}
	}

	public boolean isEmpty() {
		if (top == -1) {
			// stack is empty
			return true;
		} else {
			return false;
		}
	}

	public boolean isFull() {
		if (top == maxSize - 1) {
			// stack is full
			return true;
		} else {
			return false;
		}
	}

	public int pop() {
		if (isEmpty() == true) {
			System.out.println("Stack is empty");
			return -1;
		} else {
			int topElement = stackArr[top];
			top = top - 1;
			return topElement;
		}
	}

	public void print() {
		System.out.print("Elements in stack using for loop :");
     
		for (int i = 0; i <= top; i++) {
			System.out.print(stackArr[i] + " ");
		}
		System.out.println();
		// using array
		System.out.println("Elements in stack using array to-string :" +Arrays.toString(stackArr));
	}

}
