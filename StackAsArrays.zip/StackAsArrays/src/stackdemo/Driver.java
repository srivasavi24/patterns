package stackdemo;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StackArray myStack = new StackArray(6);
		myStack.myPush(54);myStack.myPush(66);myStack.myPush(59);
		myStack.myPush(23);myStack.myPush(89);myStack.myPush(47);
		
		// to print elements using for loop
		myStack.print();
		 
		myStack.pop();
		myStack.print();
		
	}

}
