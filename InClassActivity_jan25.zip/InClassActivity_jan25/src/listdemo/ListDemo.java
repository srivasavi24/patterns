package listdemo;
import java.util.*;
public class ListDemo {
		
	
	public static void main(String[] args) {
		int[] arrObj = {10,20,30,40,50};
		ArrayList<String> arrListObj = new ArrayList<>();
		
		System.out.println("Length of Array : " +arrObj.length);
		System.out.println("Size of ArrayList : " +arrListObj.size());
		//Adding elements to ArrayList
		arrListObj.add("Sahithi");arrListObj.add("Akhil");arrListObj.add("Fellah");arrListObj.add("Likhitha");
		//Printing Size of arraylist
		System.out.println(arrListObj.size());
		//printing arraylist elements
		System.out.println(arrListObj);
		//deleting arraylist elements
		arrListObj.remove(1);
		System.out.println("After deleting index 1 :"+arrListObj);
		arrListObj.set(0,"Anu");
		System.out.println("After updating :"+arrListObj);
		System.out.println("elements at index 1:"+arrListObj.get(1));
		for(int i=0;i<arrListObj.size();i++ ) {
			arrListObj.remove(i);
		}
		System.out.println("After loop :"+arrListObj);
		
		
	}

}
