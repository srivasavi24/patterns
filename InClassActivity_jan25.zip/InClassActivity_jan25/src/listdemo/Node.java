package listdemo;

public class Node {
	int data;
	Node next;
	//default constructor
	public Node() {
		
	}
	//parametrized constructor
		public Node(int num) {
			data = num;
		}
}
