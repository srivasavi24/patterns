package listdemo;

public class LinkedListDemo {

	
	public static int AvgOfList(Node head) {
		int sum =0;
		while(head != null) {
			sum = sum+ head.data;
			head = head.next;
			
		}
		System.out.println(sum);
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating firstnode
		Node firstNode = new Node(10);
		// print node
		System.out.println(" firstNode data :" + firstNode.data);
		System.out.println(" firstNode next:" + firstNode.next);

		// creating secondnode
		Node secondnode = new Node(20);
		// print node
		System.out.println(" secondnode data :" + secondnode.data);
		System.out.println(" secondnode next:" + secondnode.next);

		// creating thirdnode
		Node thirdnode = new Node(30);
		// print node
		System.out.println(" thirdnode data :" + thirdnode.data);
		System.out.println(" thirdnode next:" + thirdnode.next);
		// creating fourthnode
		Node fourthnode = new Node(40);
		// print node
		System.out.println(" fourthnode data :" + fourthnode.data);
		System.out.println(" fourthnode next:" + fourthnode.next);

		// linking nodes
		firstNode.next = secondnode;
		secondnode.next = thirdnode;
		thirdnode.next = fourthnode;
		// printing the linkedlist

		// print address of nodes
		System.out.println(" firstnode  :" + firstNode);
		System.out.println(" secondnode  :" + secondnode);
		System.out.println(" thirdnode  :" + thirdnode);
		System.out.println(" fourthnode  :" + fourthnode);
		
		Node current = firstNode;
		while (current != null) {
			System.out.print(current.data + " ->");
			current = current.next;
		}
		
		//method to calculate avg
		AvgOfList(firstNode);

	}

}
