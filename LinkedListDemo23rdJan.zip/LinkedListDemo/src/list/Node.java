package list;

public class Node {
	int data;
	Node next; // This variable points to the next node
	
	//constructor with no parameter's or default
	public Node() {

	}
	
	//Parameterized constructor
	public Node(int nb) {
		data = nb;
	}
}
