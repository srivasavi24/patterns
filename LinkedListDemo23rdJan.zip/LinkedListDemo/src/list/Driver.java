package list;

public class Driver {
	
	public static boolean search(int[] array, int value) {
		for(int i=0;i<array.length;i++) {
			if(array[i] == value) {
				return true;
			}
		}
		return false;
	
	}
	
	public static boolean searchList(Node head, int value) {
		
		while(head!=null) {
			System.out.println("Search in SearchList");
			if(head.data == value) {
				return true;
			}
			head = head.next;
		}
		return false;
	
	}
	
	public static void print(Node head) {
		while(head!=null) {
			System.out.print(head.data+" ");
			head = head.next;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// First Node
		Node fNode = new Node(11);	
		
		
		System.out.println(" First Node data "+fNode.data);
		System.out.println(" Frist Node next "+fNode.next);
		
		// Second Node
		Node sNode = new Node(22);
		
		//Linking the second Node to first Node
		fNode.next = sNode;
		
		System.out.println(" Second Node data "+sNode.data);
		System.out.println(" Second Node next "+sNode.next);	
		
		//Third Node
		Node tNode = new Node(33);
		//Linking the third Node to second Node
		sNode.next = tNode;
		
		System.out.println(" Third Node data "+tNode.data);
		System.out.println(" Third Node next "+tNode.next);

		System.out.println("Addresses of Nodes");
		System.out.println("Address of firstNode: "+ fNode);
		System.out.println("Address of second Ndoe: "+ sNode);
		System.out.println("Address of Third Node: "+ tNode);
		
		//Save the First Node
		
		Node currNode = fNode;
		
		while(currNode !=null) {
			System.out.print(currNode.data+ " ");
			currNode = currNode.next;
		}
		
		int[] arr1 =  {5,10,15,20,25};
		
		
		System.out.println("Element found: Yes/No " + search(arr1,100));
		
		System.out.println("Element found in LinkedList: Yes/No " + searchList(fNode, 22));
		
		// Fourth Node
		
		Node fourthNode = new Node();
		fourthNode.data = 44;
		tNode.next = fourthNode;
		
		print(fNode);
		
	}

}
