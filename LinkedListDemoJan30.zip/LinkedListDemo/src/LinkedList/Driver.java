package LinkedList;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class Driver {
	public static void main(String[] args) {
		
		//Declaring and instantiating LinkedList Object 
		LinkedList<String> list = new LinkedList<>();
		
		// Adding Elements in the Linked List
		list.add("Sushma");list.add("Priya");list.add("Rachana");
		list.add("Mahitha");list.add("Akhila");list.add("Shabna");
		list.add("Abhishek");
		
		//Printing Linked List
		System.out.println(list);
//		//Adding the element at index
//		list.add(1, "Varun");
//		list.set(7, "Akhil");
//		//Printing Linked List
//		System.out.println(list);
//		
//		list.remove("Mahitha");
//		//Printing Linked List
//		System.out.println(list);
//		
//		list.clear();
//		
//		//Printing Linked List
//		System.out.println(list);	
//		
		// Using Iterator
		
		Iterator<String> itr = list.listIterator();
		
		System.out.println("itr has next element: "+itr.hasNext());
//		System.out.println("itr next element: "+itr.next());
		// Iterating through the list
		while(itr.hasNext() == true) {
			String element = itr.next();
			//System.out.print(element+" ");
			if(element.equals("Sushma")) {
				itr.remove();
			}
			System.out.print(element+" ");
		}
		
		System.out.println("\n"+list);
		
		

		
		
	}
}
