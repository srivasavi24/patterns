package doublyLinkiedList;

public class Node {
	String name;
	Node prev;
	Node next;
	
	public Node(String std) {
		name = std;
	}
	
}
