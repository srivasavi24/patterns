package queuedemo;

import java.util.*;

public class LinkedListQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Implementing queues(I) using linkedlist(c)
		Queue<String> bankQueue = new LinkedList<>();
		
		bankQueue.add("customer1");
		bankQueue.add("customer2");
		bankQueue.add("customer3");
		bankQueue.add("customer4");
		bankQueue.offer("customer5");
		
		//Implementing queue(I) using ArrayDeque(C)
		Queue<String> arrDeque = new ArrayDeque<>();
		
		//Implementing queue(I) using PriorityQueue(C) 
		Queue<String> prioQue = new PriorityQueue<>();
		
		// printing the elements of queue
		System.out.println("Elements in queue :" + bankQueue);

		// removing elements
		bankQueue.remove();
		// printing the elements of queue
		System.out.println("Elements in queue after removing :" + bankQueue);

		/*
		 * while (!bankQueue.isEmpty()) { System.out.println("Serving :" +
		 * bankQueue.remove()); }
		 */
		
		System.out.println(bankQueue.poll());
		System.out.println("Elements in queue after poll :" + bankQueue);
		
		//peek returns head element
		System.out.println(bankQueue.peek());

		// if queue is empty it returns exception otherwise  returns head element
		System.out.println(bankQueue.element());
		
		
		System.out.println("Size :"+ bankQueue.size());
		

	}

}
