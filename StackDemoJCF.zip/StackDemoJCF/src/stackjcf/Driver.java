package stackjcf;

import java.util.*;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> stk = new Stack<>();
		stk.push("cat");
		stk.push("lion");
		stk.push("dog");
		stk.push("rabbit");

		System.out.print("Elements in stack:");
		System.out.println(stk);

		System.out.println("Top element in stack:" + stk.peek());

		System.out.println(stk.isEmpty());
		System.out.println("Size of stack:" + stk.size());
	}

}
