/**
 * 
 */
package stack;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author Khaja Nayab Rasool Shaik
 */
public class SwapStackElements {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
		Stack<Integer> integerStack = new Stack<Integer>();
		Deque<Integer> deq = new ArrayDeque<Integer>();
		System.out.print("Enter the capacity: ");
		int length = scan.nextInt();
		System.out.println("Enter " + length + " numbers: ");
		for(int i=0; i<length; i++) {
			integerStack.push(scan.nextInt());
		}
		System.out.println("Stack Elements: " +integerStack);
		
		System.out.print("Enter the first index to swap: ");
		int firstValue = scan.nextInt();
		System.out.print("Enter the second index to swap: ");
		int secondValue = scan.nextInt();
		if(firstValue == -1 || secondValue == -1 || firstValue == integerStack.size() || secondValue ==integerStack.size()) {
			System.out.println("Invalid indices.");
		}
		else {
			int element1 = integerStack.get(firstValue);
			int element2 = integerStack.get(secondValue);
			int size = integerStack.size()-1;
			for(int i=0; i<=size; i++) {
				if(i == (size-firstValue)) {
					deq.offerFirst(element2);
					integerStack.pop();
				}
				else if(i == (size-secondValue)) {
					deq.offerFirst(element1);
					integerStack.pop();
				}
				else {
					int q = integerStack.pop();
					deq.offerFirst(q);
				}
			}
			System.out.println("After swapping the stack: " +deq);
		}
	}
}


