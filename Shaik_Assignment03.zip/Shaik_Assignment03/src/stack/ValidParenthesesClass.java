/**
 * 
 */
package stack;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author Khaja Nayab Rasool Shaik
 */
public class ValidParenthesesClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter any string: ");
		String input = scan.nextLine();
		Stack<String> operands = new Stack<String>();
		Stack<String> operators = new Stack<String>();
		Stack<String> braces = new Stack<String>();
		Stack<String> check = new Stack<String>();
		int flag=0;
	    for(int i=0; i<input.length(); i++) {
	    	if((input.charAt(i)>='A' && input.charAt(i)<='Z') || 
	    			(input.charAt(i)>='a' && input.charAt(i) <= 'z') || 
	    			(input.charAt(i)>='0' && input.charAt(i) <= '9')) {
	    		operands.push(String.valueOf(input.charAt(i)));
	    	}
	    	else if(input.charAt(i)=='{' || input.charAt(i)=='}' || 
	    			input.charAt(i)=='(' || input.charAt(i)==')' || 
	    			input.charAt(i)=='[' || input.charAt(i)==']') {
	    		braces.push(String.valueOf(input.charAt(i)));
	    	}
	    	else if(input.charAt(i)==' ') {
	    		continue;
	    	}
	    	else if(input.charAt(i)=='@' || input.charAt(i)=='$') {
	    		flag++;
	    		continue;
	    	}
	    	else {
	    		operators.push(String.valueOf(input.charAt(i)));
	    	}
	    }
	    
	    if(flag!=0) {
	    	System.out.println("Input String must contain numbers, alphabets, and mathematical operators.");
	    }
	    else {
	    	System.out.println("Operands stack: " +operands);
	 	    System.out.println("Operators stack: " +operators);
	 	    System.out.println("Braces stack: " +braces);
	    
	 	    for(String s : braces) {
	 	    	if(s.equals("{" )|| s.equals("(" ) || s.equals("[" )) {
	 	    		check.push(s);
	 	    	}
	 	    	else {
	 	    		if(check.size() == 0) {
	 	    			check.push(s);
	 	    		}
	 	    		else {
	 	    			check.pop();
	 	    		}
	 	    	}
	 	    }

	 	    if(check.size() == 0) {
	 	    	System.out.println("The braces are closed correctly.");
	 	    }
	 	    else {
	 	    	System.out.println("The braces aren't closed correctly.");
	 	    }
	    }
	}
}
