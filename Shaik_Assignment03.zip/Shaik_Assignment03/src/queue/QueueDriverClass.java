/**
 * 
 */
package queue;
import java.util.Scanner;

/**
 * @author Khaja Nayab Rasool Shaik
 */
public class QueueDriverClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		QueuesUsingLinkedList queueObject = new QueuesUsingLinkedList();
        Scanner scan = new Scanner(System.in);
        char exit;
		do {
			System.out.println("Queue using Linked List Operations\r\n"
            		+ "1. Enqueue\r\n"
            		+ "2. Dequeue\r\n"
            		+ "3. Print\r\n"
            		+ "4. Size\r\n"
            		+ "5. Check Empty or not\r\n"
            		+ "6. Exit\r\n"
            		+ "");
            System.out.print("Enter your choice: ");
            int s = scan.nextInt();
            switch(s) {
        		case 1:
        			System.out.print("Enter an element to insert: ");
        			int element = scan.nextInt();
        			queueObject.enqueue(element);
        			System.out.println(element +" is inserted into the queue");
        			break;
        		case 2:
        			int value = queueObject.dequeue();
        			System.out.println(value +" is removed from queue");
        			break;
        		case 3:
        			queueObject.print();
        			break;
        		case 4:
        			int size = queueObject.size();
        			System.out.println("Size of the queue = " +size);
        			break;
        		case 5:
        			if(queueObject.isEmpty()) {
        				System.out.println("Queue is empty");
        			}
        			else {
        				System.out.println("Queue is not empty");
        			}
        			break;
        		case 6:
                    System.out.print("Do you want to exit(y/n): ");
                    exit = scan.next().charAt(0);
                    if (exit == 'y' || exit == 'Y') {
                    	System.out.println("Operations on queue are done.");
                        System.exit(0);
                    }
                    break;
                default:
                	System.out.println("The choice is not present in the list");
            }
		}while(true);
    }
}



