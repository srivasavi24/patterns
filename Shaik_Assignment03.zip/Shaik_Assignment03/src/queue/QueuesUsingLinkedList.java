/**
 * 
 */
package queue;

/**
 * @author Khaja Nayab Rasool Shaik
 */
public class QueuesUsingLinkedList {
	 Node head;
	 public void enqueue(int x) {
		 Node newNode = new Node(x);
		 if(head == null) {
			head = newNode;
		 }
		 else {
			Node temp = head;
			while(temp.next!=null) {
				temp = temp.next;
			}
			temp.next = newNode;
		 }
	 }
	 
	 public int dequeue() {
		 if (isEmpty()) {
		     System.out.println("Queue is empty");
		     return -1; 
		 }
		 else {
			 int temp = head.data;
			 head = head.next;
			 return temp;
		 }
	 }
	 
	 public boolean isEmpty() {
		 if(head == null) {
			 return true;
		 }
		 return false;
	 }

	 public int size() {
		 int x = 0;
		 Node temp = head;
		 while(temp!=null) {
			 temp = temp.next;
			 x++;
		 }
		 return x;
	 }
	 
	 public void print() {
		 Node temp = head;
		 System.out.print("Elements in queue: [");
		 while(temp.next!=null) {
			 System.out.print(temp.data+",");
			 temp = temp.next;
		 }
		 System.out.print(temp.data+"]\n");
	 }
}

