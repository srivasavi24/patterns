/**
 * 
 */
package arraylist;

import java.util.*;
import java.lang.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	ArrayList<Integer> numberList = new ArrayList<Integer>(15);

	ArrayList<Integer> arrayIndex = new ArrayList<Integer>(15);
	{
		//generating random values from 100 to 150 for numberList
		for (int i = 0; i < 15; i++) {
			numberList.add((int) (Math.random() * (150 - 100 + 1) + 100));
		}
		
		System.out.print("Initial Random Numbers in ArrayList: "+numberList);
		System.out.println();
		System.out.println("Size of ArrayList "+numberList.size());
		System.out.println();
		//generating random values from 1 to 15 for arrayIndex
		for (int j = 0; j < 15; j++) {
			arrayIndex.add((int) (Math.random() * (50 - 1 + 1) + 1));
		}
		
		for (int k = 0; k < 15; k++) {
			numberList.set(k, (int) (Math.random() * (150 - 1 + 1) + 1));
		}
		
		System.out.print("Updated Random Numbers in ArrayList: "+numberList);
		System.out.println();
		System.out.println("Size of ArrayList "+numberList.size());
		System.out.println();
		
		//Removing values at random indexes
		Random random= new Random();
		
		for (int k=0;k <7; k++) {
			int x=random.nextInt(numberList.size());
				numberList.remove(x);
		}
				

		System.out.print("ArrayList after removing 7 numbers: "+numberList);
		System.out.println();
		System.out.println("Size of ArrayList "+numberList.size());
		System.out.println();
		
		//Adding numbers at random indexes
		for (int k=0;k <7; k++) {
			int x=random.nextInt(51)+150;
			int y=random.nextInt(numberList.size()+1);
			numberList.add(y,x);
		}
		
		System.out.print("ArrayList after adding numbers: "+numberList);
		System.out.println();
		System.out.println("Size of ArrayList "+numberList.size());
		System.out.println();
		
	}

		

	}
}
