package linkedlist;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		ArrayList<String> arrListOne = new ArrayList<String>();
		ArrayList<String> arrListTwo = new ArrayList<String>();
		ArrayList<String> array = new ArrayList<String>();
		System.out.println("Enter 10 names:");
		for (int i = 1; i <= 10; i++) {
			System.out.print("Name " + i + " for " + (i % 2 == 0 ? "542: " : "642: "));
			String courseName = s.next();
			array.add(courseName + (i % 2 == 0 ? "_542" : "_642"));
			if (i % 2 == 0) {
				arrListOne.add(courseName);
			} else {
				arrListTwo.add(courseName);
			}
		}
		System.out.println("Entered names:");
		for (String i : array) {
			System.out.println(i);
		}
		System.out.println();
		CourseList course = new CourseList();
		course.addCourseList(arrListOne);
		course.addCourseList(arrListTwo);
		course.printNames();

		ArrayList<String> removedelement = course.removeNames();
		System.out.println("Names after randomly removing one element from each list.");
		course.printNames();

		ArrayList<Node> listnodes = course.getLinkedLists();

		LinkedList listone = new LinkedList();
		LinkedList listtwo = new LinkedList();
		listone.head = listnodes.get(0);
		listtwo.head = listnodes.get(1);

		System.out.println("Linked List 1 elements: ");
		listone.printLinkedList();

		System.out.println("Linked List 2 elements: ");
		listtwo.printLinkedList();

		LinkedList mergelist = new LinkedList();
		mergelist.mergeLinkedList(listone.head, listtwo.head);
		System.out.println("Merge Node Elements:");
		mergelist.printLinkedList();

		System.out.println("After removing element at Tail:");
		mergelist.removeTail();
		mergelist.printLinkedList();

		System.out.println("After Adding elements at Head and Tail:");
		mergelist.addEnd(new Node(removedelement.get(0)));
		mergelist.addStart(new Node(removedelement.get(1)));
		mergelist.printLinkedList();
	}

}
