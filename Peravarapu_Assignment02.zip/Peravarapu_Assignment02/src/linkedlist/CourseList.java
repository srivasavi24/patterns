/**
 * 
 */
package linkedlist;
import java.util.*;
import java.lang.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */
public class CourseList {
	
	ArrayList<ArrayList<String>> courses;

	public CourseList() {
		this.courses = new ArrayList<ArrayList<String>>();
	}
	Scanner n=new Scanner(System.in);
	String s;
	
	public void addCourseList(ArrayList<String> course) {
     courses.add(course);	
	}
	Random random = new Random();
	
	public ArrayList<String> removeNames(){
		ArrayList<String> removeselement= new ArrayList<>();
		for(int i=0;i<courses.size();i++) {
			var course = courses.get(i);
			var randomindex=random.nextInt(0,courses.size());
			removeselement.add(course.remove(randomindex));
		}
		return removeselement;
	}
	
	public void printNames() {
		if(courses.size()==2) {
			System.out.println("Names in course 542: "+courses.get(0));
			System.out.println("Names in course 642: "+courses.get(1));
		}
		
	}
	
	public ArrayList<Node> getLinkedLists() {
		var list1= new ArrayList<Node>();
		for(int i=0;i<courses.size();i++) {
			var course=courses.get(i);
			if(course.size()>0) {
				LinkedList list = new LinkedList();
				list.head=new Node(course.get(0));
					for(int j=1;j<course.size();j++) {
						Node nextnode=new Node(course.get(j));
						list.addEnd(nextnode);
						
					}
					list1.add(list.head);
				}
			}
		return list1;
		
		
	}

}
