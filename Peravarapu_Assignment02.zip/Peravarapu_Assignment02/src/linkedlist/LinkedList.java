package linkedlist;

import java.util.*;
import java.lang.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class LinkedList {

	Node head;

	public LinkedList() {
//		head=null;
	}
	
	
	/*
	 * method to connect two ArrayLists
	 * returns nothing
	 * Takes two parameters as input head and new node to link the arrays 
	 */
	public void mergeLinkedList(Node head, Node connectNode) {
		Node temp = head;
		while(head.next!=null) {
			head = head.next;
			
			
		}
		head.next = connectNode;
		this.head=temp;
	}
	/*
	 * method to add node at start
	 */
	public void addStart(Node addNode) {
		addNode.next=head;
		head=addNode;
	}
	
	/*
	 * method to add node at end
	 */
	public void addEnd(Node endNode) {
		Node current=head;
		while(current.next!=null) {
			current=current.next;
		}
		current.next=endNode;
	}
	/*
	 * method to print linkedlist
	 */
	public void printLinkedList() {
		Node current = head;
		while(current != null && current.next != null) {
			System.out.print(current.name + " ");
			current = current.next;
		}
		if (current != null) {
			System.out.print(current.name);
			System.out.println();
		}
	}
	
	/*
	 * method to remove element at end
	 */
	public void removeTail() {
		Node current = head.next;
		Node previous=head;
		while(current.next!=null) {
			current=current.next;
			previous=previous.next;
			
		}
		previous.next=null;
	}
}
