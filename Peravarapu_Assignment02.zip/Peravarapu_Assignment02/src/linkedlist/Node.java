package linkedlist;

import java.util.*;
import java.lang.*;

/**
 * @author S566425 Sri Vasavi Peravarapu
 */

public class Node {
	String name;
	Node next;
	public Node(String name) {
		this.name = name;
	}
	
	
}
