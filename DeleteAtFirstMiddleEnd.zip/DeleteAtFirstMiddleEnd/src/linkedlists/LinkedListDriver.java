package linkedlists;
public class LinkedListDriver {
	
	// Printing the linked list
	public static void printList(Node current) {
		System.out.print("Linked List: ");
		while(current != null) {
			System.out.print(current.data + " -> ");
			current = current.next;
		}
	}
	
	// Delete the first node
	public static Node deleteFirst(Node head) {
		Node newHead = head.next;
		return newHead;
	}
	
	// Delete the middle node
	public static Node deleteAtMiddle(Node head, int value) {
		Node current = head;
		Node prevNode = null;
		while(current.data != value) {
			prevNode = current;
			// System.out.println("PrevNode Data :" +prevNode.data);
			current = current.next;
		}
	    // System.out.println("Current Node Data :"+ current.data);
	    prevNode.next = current.next;
	    return head;
	}
	
	// Delete the last node
	public static Node deleteLast(Node head) {
		Node current = head;
		Node previousNode = null;
		while(current.next != null) {
			previousNode = current;
			// System.out.println("Previous data = " + previousNode.data);
			current = current.next;
		}
		previousNode.next = null;
		return head;
	}
	
	// Extending the list
	public static Node extendList(Node head, int data) {
		Node current = head;
		while(current.next != null) {
			current = current.next;
		}
		Node newNode = new Node(data);
		current.next = newNode;
		return head;
	}
	
	// Finding maximum element in the linked list
	public static int findMaxElement(Node head) {
		int maxValue = head.data;
		Node current = head.next;
		while(current != null) {
			if(current.data > maxValue) {
				maxValue = current.data;
			}
			current = current.next;
		}
		return maxValue;
	}
	
	public static void main(String[] args) {
		// Create a node
		Node head = new Node(10);
		System.out.println("Data in head = " + head.data);
		System.out.println("head of next = " + head.next);
		// Create a second node
		Node second_node = new Node(15);
		System.out.println("Data in second node = " + 
							second_node.data);
		System.out.println("second node next = " + 
					second_node.next);
		// Printing the address of nodes
		System.out.println("Head = " + head);
		System.out.println("Second node = " + second_node);
		// Linking the second_node to head
		head.next = second_node;
		// Create a third node
		Node third_node = new Node(20);
		System.out.println("Third node address = "+third_node);
		// Linking third_node to second_node
		second_node.next = third_node;
		
		/* 
		 * Insert a new node of data -5 at the beginning 
		 * of the list, then update the head of the list
		 * Linked List: 10 -> 15 -> 20
		 * Updated: -5 -> 10 -> 15 -> 20 
		*/
		Node firstNode = new Node(-5);
		firstNode.next = head;
		head = firstNode;  // head is updated
		
		// Printing the linked list
		// Create a new node "current" to store head 
		Node current = head;
		System.out.println("Data in current = " + 
							current.data);
//		System.out.print("Linked List: ");
//		while(current != null) {
//			System.out.print(current.data + " -> ");
//			current = current.next;
//		}
		// Calling the printList method
		printList(current);
		
		/*
		 * Create a new node (middleNode) with data 642 and
		 * insert it after node 10 in the linked list
		 * Linked List: -5 -> 10 -> 15 -> 20
		 * Updated: -5 -> 10 -> 642 -> 15 ->  20
		 */
		System.out.println("\nInsertion at middle :");
		Node current1 = head;
		Node middleNode = new Node(642);
		// Looping until we get node having data 10
		while (current1.data != 10) {
			current1 = current1.next;
		}
		// Linking the nodes
		middleNode.next = current1.next;
		current1.next = middleNode;
		printList(head);
		
		/*
		 * Create a new node (lastNode) with data 999 and
		 * insert it at the end of the linked list
		 * Linked List: -5 -> 10 -> 642 -> 15 -> 20
		 * Updated: -5 -> 10 -> 642 -> 15 ->  20 -> 999
		 */
		Node current2;
		current2 = head;
		while(current2.next!=null)
		{
			current2=current2.next;
		}
		Node lastNode = new Node(999);
		current2.next = lastNode;
		//System.out.println(current2.data);
		System.out.println("\nInsertion at end: ");
		printList(head);
		
		
		/*
		 * Write a method "deleteFirst"
		 * to delete the head node
		 * Linked List: -5 -> 10 -> 642 -> 15 -> 20 -> 999
		 * Updated: 10 -> 642 -> 15 ->  20 -> 999
		 */
		head = deleteFirst(head);
		System.out.println("\nAfter deleting first node: ");
		printList(head);
		
		/*
		 * Write a method "deleteAtMiddle"
		 * to delete node with data 20
		 * Linked List: 10 -> 642 -> 15 -> 20 -> 999
		 * Updated: 10 -> 642 -> 15 -> 999
		 */
		head = deleteAtMiddle(head, 20);
	    System.out.println("\nList after deleting the Node 20 :");
	    printList(head);
	    
	    /*
	     * Write a method "deleteLast"
	     * to delete the last node from the linked list
	     * Linked List: 10 -> 642 -> 15 -> 999
		 * Updated: 10 -> 642 -> 15
	     */
	    head = deleteLast(head);
	    System.out.println("\nAfter deleting last node: ");
	    printList(head);
	    
	    /*
	     * Extend
	     */
	    head = extendList(head, 55);
	    head = extendList(head, 11);
	    head = extendList(head, 22);
	    head = extendList(head, 33);
	    System.out.println("\nAfter extenstion: ");
	    printList(head);
	    
	    /*
	     * Write a method "findMaxElement"
	     * to return the maximum element of the linked list
	     * Linked List: 10 -> 642 -> 15 -> 55 -> 11 -> 
	     * 				22 -> 33
		 * Maximum Value: 642
	     */
	    int maxValue = findMaxElement(head);
	    System.out.println("\nMaximum element of list: " 
	    					+ maxValue);
	}
	
}
