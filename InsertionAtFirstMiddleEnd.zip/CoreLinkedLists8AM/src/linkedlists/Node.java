package linkedlists;

public class Node {
	// To store the data
	int data;
	// To store the reference of next node
	Node next;
	// constructor
	public Node(int number) {
		data = number;
	}
}
